(function(window, undefined) {

  var jimLinks = {
    "f9985700-b3ba-489e-a80f-9f8043332823" : {
      "grocery_bg" : [
        "3ea7ad19-a9de-49ac-883b-c5a6b5b4a03b"
      ],
      "shadow" : [
        "172fc6fb-439c-4f36-a520-4bc32fd2e96b"
      ],
      "grocery" : [
        "172fc6fb-439c-4f36-a520-4bc32fd2e96b"
      ],
      "Image_71" : [
        "3ea7ad19-a9de-49ac-883b-c5a6b5b4a03b"
      ]
    },
    "bc3315fb-8ceb-4757-9d01-ddc9740b7ac9" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "edadb403-55a6-4487-bc98-181382b91099" : {
      "Button_2" : [
        "0f73eb60-f343-479b-ab0f-828da6ba360e"
      ]
    },
    "0f73eb60-f343-479b-ab0f-828da6ba360e" : {
      "Button_2" : [
        "c1ad5c33-35df-474f-b541-cd64edefc3a4"
      ]
    },
    "3ea7ad19-a9de-49ac-883b-c5a6b5b4a03b" : {
      "Image_1" : [
        "402e18e0-206e-40a2-951f-c54fd4b6afc9"
      ],
      "Text_3" : [
        "402e18e0-206e-40a2-951f-c54fd4b6afc9"
      ],
      "Two-line-item_24" : [
        "f9985700-b3ba-489e-a80f-9f8043332823"
      ],
      "Two-line-item_34" : [
        "fc3524fe-4015-4132-a436-b61fa3a1f3a9"
      ],
      "Two-line-item_12" : [
        "c9767d5f-4cc2-43c2-91c0-b949ba42a761"
      ],
      "Two-line-item_23" : [
        "a275aebd-5a17-4ad1-bf5d-cbaa02c373de"
      ],
      "Two-line-item_28" : [
        "7e84dbf7-ef51-454c-a4b0-684439cabf3c"
      ]
    },
    "c1ad5c33-35df-474f-b541-cd64edefc3a4" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "384e0777-03d0-4802-9e9e-8a78f7dbf47e" : {
      "Image_2" : [
        "bc3315fb-8ceb-4757-9d01-ddc9740b7ac9"
      ]
    },
    "d2da056c-a96d-44fd-aacf-c4fb02e796cc" : {
    },
    "8ab53486-d338-4bb7-a8cc-628c20f56503" : {
      "raised_Button" : [
        "2e7445e4-af9a-4cb2-9495-438d88a91d9c"
      ]
    },
    "2e7445e4-af9a-4cb2-9495-438d88a91d9c" : {
      "Button_1" : [
        "384e0777-03d0-4802-9e9e-8a78f7dbf47e"
      ],
      "Text_11" : [
        "ae56c68d-a7aa-41eb-8308-d6a3504a322f"
      ]
    },
    "ae56c68d-a7aa-41eb-8308-d6a3504a322f" : {
      "Button_1" : [
        "edadb403-55a6-4487-bc98-181382b91099"
      ]
    },
    "172fc6fb-439c-4f36-a520-4bc32fd2e96b" : {
      "Image_1" : [
        "402e18e0-206e-40a2-951f-c54fd4b6afc9"
      ],
      "Text_3" : [
        "402e18e0-206e-40a2-951f-c54fd4b6afc9"
      ]
    },
    "20d2267b-9037-4c71-9d6d-ed5792ccb420" : {
      "Two-line-item_1" : [
        "8ab53486-d338-4bb7-a8cc-628c20f56503"
      ],
      "Text_3" : [
        "8ab53486-d338-4bb7-a8cc-628c20f56503"
      ],
      "Text_4" : [
        "8ab53486-d338-4bb7-a8cc-628c20f56503"
      ]
    },
    "a275aebd-5a17-4ad1-bf5d-cbaa02c373de" : {
    },
    "402e18e0-206e-40a2-951f-c54fd4b6afc9" : {
      "raised_Button" : [
        "3ea7ad19-a9de-49ac-883b-c5a6b5b4a03b"
      ],
      "raised_Button_1" : [
        "172fc6fb-439c-4f36-a520-4bc32fd2e96b"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "grocery_bg" : [
        "3ea7ad19-a9de-49ac-883b-c5a6b5b4a03b"
      ],
      "shadow" : [
        "172fc6fb-439c-4f36-a520-4bc32fd2e96b"
      ],
      "grocery" : [
        "172fc6fb-439c-4f36-a520-4bc32fd2e96b"
      ],
      "Text_9" : [
        "2e7445e4-af9a-4cb2-9495-438d88a91d9c"
      ],
      "Text_10" : [
        "ae56c68d-a7aa-41eb-8308-d6a3504a322f"
      ]
    },
    "0301ac40-598f-458f-9533-4f16ac4d14b0" : {
      "Image_1" : [
        "402e18e0-206e-40a2-951f-c54fd4b6afc9"
      ],
      "Text_3" : [
        "402e18e0-206e-40a2-951f-c54fd4b6afc9"
      ]
    },
    "644113e6-e405-429e-bb83-9d27c9ef1d5d" : {
      "grocery_bg" : [
        "3ea7ad19-a9de-49ac-883b-c5a6b5b4a03b"
      ],
      "shadow" : [
        "172fc6fb-439c-4f36-a520-4bc32fd2e96b"
      ],
      "grocery" : [
        "172fc6fb-439c-4f36-a520-4bc32fd2e96b"
      ]
    },
    "97f73eaa-c68b-4c27-8807-280d5936da4d" : {
      "Text_9" : [
        "2e7445e4-af9a-4cb2-9495-438d88a91d9c"
      ],
      "Text_10" : [
        "ae56c68d-a7aa-41eb-8308-d6a3504a322f"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);