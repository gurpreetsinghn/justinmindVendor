function initData() {
  jimData.variables["Total"] = "500";
  jimData.isInitialized = true;
}